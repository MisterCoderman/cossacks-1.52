void HandleTransport();
bool CreateTransProcess(OneObject* TRA);
bool CheckTransportOnParking(OneObject* TRA,int x,int y);