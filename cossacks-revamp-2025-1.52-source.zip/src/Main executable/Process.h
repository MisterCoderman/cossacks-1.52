void SetupInfMessage(char* Header);
void SetNextInfStage(char* Message);
void ShowProcessInfo();